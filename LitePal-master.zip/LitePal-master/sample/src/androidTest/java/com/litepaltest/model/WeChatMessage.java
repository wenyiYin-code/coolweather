package com.litepaltest.model;

public class WeChatMessage extends Message {

    private String friend;

    public String getFriend() {
        return friend;
    }

    public void setFriend(String friend) {
        this.friend = friend;
    }
}
